<?php

$firstName = 'David';

echo $firstName;