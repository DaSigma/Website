<?php
$submitted = false;

if($submitted) {
    $message = 'Thank you';
}

echo $message;