<?php

$firstName = 'David';

echo $firstname;