<li><img src="<?= $siteroot; ?>/images/artists/Barot_Bellingham_tn.jpg" alt="Barot Bellingham"></li>
<li><img src="<?= $siteroot; ?>/images/artists/Constance_Smith_tn.jpg" alt="Constance Smith"></li>
<li><img src="<?= $siteroot; ?>/images/artists/Hassum_Harrod_tn.jpg" alt="Hassum Harrod"></li>
<li><img src="<?= $siteroot; ?>/images/artists/Hillary_Goldwynn_tn.jpg" alt="Hillary Goldwynn"></li>
<li><img src="<?= $siteroot; ?>/images/artists/Jennifer_Jerome_tn.jpg" alt="Jennifer Jerome"></li>
<li><img src="<?= $siteroot; ?>/images/artists/Jonathan_Ferrar_tn.jpg" alt="Jonathan Ferrar"></li>
<li><img src="<?= $siteroot; ?>/images/artists/LaVonne_LaRue_tn.jpg" alt="LaVonne LaRue"></li>
<li><img src="<?= $siteroot; ?>/images/artists/Riley_Rewington_tn.jpg" alt="Riley Rewington"></li>
<li><img src="<?= $siteroot; ?>/images/artists/Xhou_Ta_tn.jpg" alt="Xhou Ta"></li>

