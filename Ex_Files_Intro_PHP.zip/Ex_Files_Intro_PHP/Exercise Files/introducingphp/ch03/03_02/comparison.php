<?php
$name = 'Arthur Dent';

if ($name == 'Arthur Dent') {
    echo 'I could never get the hang of Thursdays.';
} elseif ($name == 'Marvin') {
    echo "I've got this terrible pain in all the diodes down my left-hand side.";
} else {
    echo 'Is that really a piece of fairy cake?';
}
