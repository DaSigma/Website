<?php
//$unit_cost = 0;



echo $wholesale_price;
