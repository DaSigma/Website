<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Mail acknowledgment</title>
<link href="styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<h1>Thank You</h1>
<p>Thank you for your comments. We'll be in touch if necessary.</p>
</body>
</html>