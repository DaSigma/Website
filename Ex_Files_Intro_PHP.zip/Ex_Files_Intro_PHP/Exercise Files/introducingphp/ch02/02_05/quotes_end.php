<?php
//$book = 'Hitchhiker\'s Guide to the Galaxy';
//$book = "Hitchhiker's Guide to the Galaxy";
//$book = '"Hitchhiker\'s Guide to the Galaxy"';
$book = "\"Hitchhiker's Guide to the Galaxy\"";

//echo $book;

//echo 'I love $book';
echo "I love $book";