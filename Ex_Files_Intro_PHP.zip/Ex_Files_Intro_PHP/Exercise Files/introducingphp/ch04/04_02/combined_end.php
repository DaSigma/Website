<?php
$total = 5;
//$total = $total + 2;
$total += 2;
$total -= 3;
$total *= 4;
echo $total;
