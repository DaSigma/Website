<?php
$a = 5;
$b = 2;

echo -$a . '<br>';
echo $a + $b . '<br>';
echo $a - $b . '<br>';
echo $a * $b . '<br>';
echo $a / $b . '<br>';

